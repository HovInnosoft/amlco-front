import { Link } from 'react-router-dom';
import { Upload, FileText, CheckCircle2, AlertCircle, ArrowRight, X } from 'lucide-react';

export default function ReportUpload() {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <Link to="/reports/new" className="text-sm text-blue-600 hover:text-blue-700 font-medium mb-4 inline-block">
          ← Back to Report Selection
        </Link>
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Upload Documents</h1>
        <p className="text-slate-600">Upload the documents needed for your AMLCO Annual Report</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl shadow-sm border-2 border-dashed border-slate-300 p-12 text-center hover:border-blue-400 transition-colors cursor-pointer">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Upload className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Drop files here or click to browse</h3>
            <p className="text-sm text-slate-600 mb-4">
              Supports PDF, DOCX, XLSX, CSV and more. Maximum 50MB per file.
            </p>
            <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors">
              Browse Files
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200">
            <div className="p-6 border-b border-slate-200">
              <h2 className="text-lg font-semibold text-slate-900">Uploaded Files (6)</h2>
            </div>
            <div className="divide-y divide-slate-200">
              <div className="p-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">Client_Onboarding_Records_2025.xlsx</p>
                      <p className="text-xs text-slate-500">2.4 MB • Uploaded 2 mins ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <button className="p-1 hover:bg-slate-200 rounded transition-colors">
                      <X className="w-4 h-4 text-slate-400" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">Transaction_Monitoring_Q4_2025.pdf</p>
                      <p className="text-xs text-slate-500">5.1 MB • Uploaded 3 mins ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <button className="p-1 hover:bg-slate-200 rounded transition-colors">
                      <X className="w-4 h-4 text-slate-400" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">SAR_Reports_2025.docx</p>
                      <p className="text-xs text-slate-500">1.8 MB • Uploaded 4 mins ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <button className="p-1 hover:bg-slate-200 rounded transition-colors">
                      <X className="w-4 h-4 text-slate-400" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">Staff_Training_Records_2025.pdf</p>
                      <p className="text-xs text-slate-500">3.2 MB • Uploaded 5 mins ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <button className="p-1 hover:bg-slate-200 rounded transition-colors">
                      <X className="w-4 h-4 text-slate-400" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">Risk_Assessment_2025.xlsx</p>
                      <p className="text-xs text-slate-500">1.5 MB • Uploaded 6 mins ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <button className="p-1 hover:bg-slate-200 rounded transition-colors">
                      <X className="w-4 h-4 text-slate-400" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">AML_Policies_Updated_2025.pdf</p>
                      <p className="text-xs text-slate-500">4.7 MB • Uploaded 7 mins ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <button className="p-1 hover:bg-slate-200 rounded transition-colors">
                      <X className="w-4 h-4 text-slate-400" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center">
            <Link
              to="/reports/new"
              className="px-6 py-2.5 bg-white text-slate-700 rounded-lg font-medium hover:bg-slate-50 transition-colors border border-slate-300"
            >
              Back
            </Link>
            <Link
              to="/reports/new/review"
              className="inline-flex items-center space-x-2 px-6 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              <span>Continue to Review</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Document Checklist</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-slate-700">Client onboarding records</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-slate-700">Transaction monitoring logs</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-slate-700">Suspicious activity reports</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-slate-700">Training records</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-slate-700">Risk assessments</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-slate-700">Policy documents</span>
              </div>
             <p></p>
              <span className="text-sm text-slate-700">* MAYBE THERE MISSING FILES THAT CAN AFFECT COMPLETENESS OF REPORT</span>
            </div>
          </div>

          <div className="bg-blue-50 rounded-xl p-6 border border-blue-200">
            <h3 className="text-sm font-semibold text-slate-900 mb-2">Tip</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Upload all available documents now. Missing documents will be flagged in the review step,
              and you can add them later if needed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
