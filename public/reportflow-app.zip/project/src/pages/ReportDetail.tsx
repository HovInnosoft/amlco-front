import { Link } from 'react-router-dom';
import { Download, FileText, CheckCircle2, AlertCircle, Edit3, Share2 } from 'lucide-react';

export default function ReportDetail() {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <Link to="/reports" className="text-sm text-blue-600 hover:text-blue-700 font-medium mb-4 inline-block">
          ← Back to Reports
        </Link>
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">AMLCO Annual Report 2025</h1>
            <p className="text-slate-600">Egard Management Ltd • Jan 1 - Dec 31, 2025</p>
          </div>
          <span className="inline-flex items-center px-3 py-1.5 rounded-full text-sm font-medium bg-green-100 text-green-700">
            <CheckCircle2 className="w-4 h-4 mr-1.5" />
            Complete
          </span>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200">
            <div className="p-6 border-b border-slate-200">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-slate-900">Report Preview</h2>
                <div className="flex items-center space-x-2">
                  <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                    <Edit3 className="w-5 h-5 text-slate-600" />
                  </button>
                  <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                    <Share2 className="w-5 h-5 text-slate-600" />
                  </button>
                  <button className="inline-flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors">
                    <Download className="w-4 h-4" />
                    <span>Download DOCX</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="p-8 bg-slate-50">
              <div className="bg-white rounded-lg shadow-sm p-12 max-w-4xl mx-auto">
                <div className="mb-8 text-center border-b border-slate-200 pb-8">
                  <h1 className="text-3xl font-bold text-slate-900 mb-3">
                    ANTI-MONEY LAUNDERING COMPLIANCE OFFICER
                    <br />
                    ANNUAL REPORT
                  </h1>
                  <p className="text-lg text-slate-600 mb-2">Egard Management Ltd</p>
                  <p className="text-slate-500">Reporting Period: January 1 - December 31, 2025</p>
                </div>

                <div className="space-y-6 text-slate-700 leading-relaxed">
                  <section>
                    <h2 className="text-xl font-bold text-slate-900 mb-3">1. Executive Summary</h2>
                    <p className="mb-3">
                      This report provides a comprehensive overview of Anti-Money Laundering (AML) and Counter-Terrorist
                      Financing (CTF) compliance activities conducted by Egard Management Ltd during the reporting period
                      of January 1, 2025 to December 31, 2025.
                    </p>
                    <p>
                      Throughout the reporting period, the Company has maintained robust AML/CTF frameworks and controls,
                      demonstrating strong commitment to regulatory compliance and best practices.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-xl font-bold text-slate-900 mb-3">2. Client Onboarding & KYC</h2>
                    <p className="mb-3">
                      During the reporting period, the Company onboarded <strong>142 new clients</strong>, all of whom
                      underwent comprehensive Know Your Customer (KYC) and Customer Due Diligence (CDD) procedures in
                      accordance with CySEC requirements and the Prevention and Suppression of Money Laundering
                      Activities Law.
                    </p>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-3">
                      <h3 className="font-semibold text-slate-900 mb-2">Key Metrics:</h3>
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        <li>Total clients onboarded: 142</li>
                        <li>Enhanced due diligence cases: 8</li>
                        <li>KYC documentation completeness: 100%</li>
                        <li>Average onboarding time: 3.2 business days</li>
                      </ul>
                    </div>
                  </section>

                  <section>
                    <h2 className="text-xl font-bold text-slate-900 mb-3">3. Transaction Monitoring</h2>
                    <p className="mb-3">
                      The Company's transaction monitoring system reviewed <strong>1,247 transactions</strong> during
                      the reporting period. Of these, <strong>8 transactions</strong> were flagged for enhanced due
                      diligence based on predefined risk indicators.
                    </p>
                    <p>
                      All flagged transactions were thoroughly investigated, documented, and resolved in accordance with
                      internal procedures and regulatory requirements.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-xl font-bold text-slate-900 mb-3">4. Suspicious Activity Reporting</h2>
                    <p className="mb-3">
                      During the reporting period, the AMLCO filed <strong>3 Suspicious Activity Reports (SARs)</strong>
                      with the Unit for Combating Money Laundering (MOKAS). All SARs were filed within the required
                      timeframes as stipulated by law.
                    </p>
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <p className="text-sm">
                        Details of individual SARs are maintained in confidential records in accordance with legal
                        requirements and are available for regulatory inspection upon request.
                      </p>
                    </div>
                  </section>

                  <section>
                    <h2 className="text-xl font-bold text-slate-900 mb-3">5. Training and Awareness</h2>
                    <p className="mb-3">
                      All <strong>18 employees</strong> completed mandatory AML/CTF training during the reporting period,
                      achieving a <strong>100% compliance rate</strong>. Training covered:
                    </p>
                    <ul className="list-disc list-inside space-y-1 mb-3 ml-4">
                      <li>AML/CTF regulatory requirements and updates</li>
                      <li>Red flag indicators and suspicious activity identification</li>
                      <li>Customer due diligence procedures</li>
                      <li>Reporting obligations and internal escalation procedures</li>
                    </ul>
                  </section>

                  <section>
                    <h2 className="text-xl font-bold text-slate-900 mb-3">6. Risk Assessment</h2>
                    <p className="mb-3">
                      The Company completed its annual enterprise-wide AML/CTF risk assessment in accordance with
                      regulatory requirements. The assessment classified the Company's overall AML/CTF risk profile
                      as <strong>medium-low</strong>.
                    </p>
                    <p>
                      Risk mitigation measures remain appropriate and proportionate to the identified risk level.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-xl font-bold text-slate-900 mb-3">7. Policies and Procedures</h2>
                    <p>
                      The Company's AML/CTF policies and procedures were comprehensively reviewed and updated during the
                      reporting period. The updated policies were approved by the Board of Directors on
                      <strong> March 15, 2025</strong>, and have been communicated to all relevant staff.
                    </p>
                  </section>

                  <section className="bg-orange-50 border-2 border-orange-300 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <AlertCircle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <h3 className="font-semibold text-slate-900 mb-2">Missing Information</h3>
                        <p className="text-sm text-slate-700 mb-2">
                          The following information could not be extracted from uploaded documents and should be
                          reviewed and completed before final submission:
                        </p>
                        <ul className="list-disc list-inside space-y-1 text-sm text-slate-700">
                          <li>External audit report findings and recommendations</li>
                          <li>Year-over-year comparison with 2024 AMLCO report</li>
                        </ul>
                      </div>
                    </div>
                  </section>

                  <section>
                    <h2 className="text-xl font-bold text-slate-900 mb-3">8. Conclusion</h2>
                    <p>
                      The AMLCO confirms that Egard Management Ltd has maintained effective AML/CTF controls throughout
                      the reporting period and has operated in compliance with applicable regulatory requirements. The
                      Company continues to demonstrate strong commitment to combating money laundering and terrorist
                      financing.
                    </p>
                  </section>

                  <div className="mt-12 pt-8 border-t border-slate-200">
                    <p className="text-slate-600">
                      <strong>Prepared by:</strong> Maria Andreou, AMLCO
                      <br />
                      <strong>Date:</strong> January 15, 2026
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Report Information</h3>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-slate-500 mb-1">Report Type</p>
                <p className="text-sm font-medium text-slate-900">AMLCO Annual Report</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Entity</p>
                <p className="text-sm font-medium text-slate-900">Egard Management Ltd</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Reporting Period</p>
                <p className="text-sm font-medium text-slate-900">Jan 1 - Dec 31, 2025</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Generated</p>
                <p className="text-sm font-medium text-slate-900">January 15, 2026</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Generated By</p>
                <p className="text-sm font-medium text-slate-900">Maria Andreou</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">File Size</p>
                <p className="text-sm font-medium text-slate-900">248 KB</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Data Sources</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span className="text-slate-600">Client_Onboarding_Records_2025.xlsx</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span className="text-slate-600">Transaction_Monitoring_Q4_2025.pdf</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span className="text-slate-600">SAR_Reports_2025.docx</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span className="text-slate-600">Staff_Training_Records_2025.pdf</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span className="text-slate-600">Risk_Assessment_2025.xlsx</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span className="text-slate-600">AML_Policies_Updated_2025.pdf</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Completeness</h3>
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600">Overall</span>
                <span className="text-sm font-semibold text-slate-900">98%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full" style={{ width: '98%' }}></div>
              </div>
            </div>
            <div className="pt-3 border-t border-slate-200 space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Critical sections</span>
                <span className="font-medium text-green-600">8/8</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Supporting data</span>
                <span className="font-medium text-green-600">13/14</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Missing items</span>
                <span className="font-medium text-orange-600">1</span>
              </div>
            </div>
          </div>

          <div className="bg-green-50 rounded-xl p-6 border border-green-200">
            <h3 className="text-sm font-semibold text-slate-900 mb-2">Ready for Review</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              This report has been successfully generated and is ready for your review and any necessary edits
              before submission to CySEC.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
